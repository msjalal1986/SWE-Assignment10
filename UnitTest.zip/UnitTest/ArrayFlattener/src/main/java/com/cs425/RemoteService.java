package com.cs425;

public interface RemoteService {
    Student fetchStudent(int studentId);
}
